> **2026-11-06 second update:** migration 009 now stores mobile leg and driver assignment metadata on original `reservation_details` / `reservation_drivers` rows, retaining archived app extension tables. Read [RESERVATION_LEG_AND_DRIVER_CONSOLIDATION.md](RESERVATION_LEG_AND_DRIVER_CONSOLIDATION.md) for current architecture and deployment cautions. The remaining document records the **historical Release 1 design**, not the current runtime table map.

> **2026-11-06 update:** `app_reservation_meta` below describes the historical extension table. The updated runtime now stores its seven mobile attributes directly on the existing `reservations` row after migration 008. See [RESERVATIONS_SINGLE_TABLE_CONSOLIDATION.md](RESERVATIONS_SINGLE_TABLE_CONSOLIDATION.md). The historical migration file is unchanged to retain checksum compatibility.

# Database compatibility and Release 1 changes

## Compatibility strategy

The API continues to use the existing `drive_luxury` database as the system of record. It writes core business records into the legacy tables and stores mobile-specific workflow state in additive `app_*` tables.

This release adds **no columns, keys, or constraints to existing legacy tables**. That is deliberate: it avoids locking or changing tables already used by the current website and back-office.

Run `npm run verify:schema` before migration/deployment. It validates the legacy tables and columns required by the API.

## Existing tables used without alteration

| Existing table                                                    | Release 1 use                                                                                               |
| ----------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `users`                                                           | Authentication and legacy role IDs: Admin 1, Staff 2, Chauffeur 3, Agency Agent 4, Client 5                 |
| `customers`                                                       | Client profile and agency relationship                                                                      |
| `agents`                                                          | Agency administrators/members; never rental inspectors                                                      |
| `agencies`                                                        | Agency status and commission percentage                                                                     |
| `drivers`                                                         | Chauffeur profile                                                                                           |
| `countries`                                                       | Active country IDs and ISO-style codes used by booking/catalog requests                                     |
| `cities`                                                          | Active city IDs, aliases, and coordinates filtered by country                                               |
| `services`                                                        | Existing website service catalog; mobile `reservations.service_type` uses Chauffeur 1, Rental 2, Transfer 3 |
| `vehicle_classes`                                                 | Client-facing vehicle-class selection                                                                       |
| `vehicles`                                                        | Physical fleet inventory; only status 1 and online-bookable rows are eligible                               |
| `vehicle_class_countries`                                         | Country eligibility for classes                                                                             |
| `vehicle_class_price_rates`                                       | Country/season/duration class prices and transfer distance fallback                                         |
| `rental_seasons`, `rental_durations`                              | Pickup-date season and closest active duration band                                                         |
| `transfer_city_wise_prices`, `vehicle_class_city_wise_base_rates` | Transfer city-pair and country/distance prices                                                              |
| `vehicle_service_types`, `vehicle_cities`                         | Eligible service and physical pickup location                                                               |
| `rental_option_classes`                                           | Per-class eligibility for optional extras                                                                   |
| `rental_options`                                                  | Extras/options                                                                                              |
| `tax_surecharges`                                                 | Percentage tax/surcharge configuration                                                                      |
| `reservations`                                                    | Booking header                                                                                              |
| `reservation_details`                                             | One record per itinerary/service leg                                                                        |
| `reservation_itineraries`                                         | Ordered intermediate/drop-off stops                                                                         |
| `reservation_costs`                                               | Per-leg price totals                                                                                        |
| `reservation_payments`                                            | Approved legacy payment ledger entry                                                                        |
| `reservation_drivers`                                             | Legacy chauffeur allocation bridge                                                                          |
| `reservation_vehicles`                                            | Physical vehicle reserved at checkout; Operations can reassign later                                        |
| `vehicle_reserved_dates`                                          | Physical-vehicle calendar block                                                                             |
| `vehicle_blocks`                                                  | Existing maintenance/manual unavailability periods used by availability checks                              |
| `vehicle_status_update_logs`                                      | Existing fleet status history retained for website/back-office compatibility                                |
| `reservation_temp_vehicle_histories`                              | Existing history of replacement vehicles per reservation leg                                                |
| `activity_logs`                                                   | Existing audit log used for operational booking decisions and vehicle changes                               |
| `agency_commissions`                                              | Operations-owned; read-only for Agent app                                                                   |
| `reservation_invoices`, `reservation_invoice_details`             | Operations-owned invoices shown read-only in mobile                                                         |

The availability rule is strict: only `vehicles.status = 1` (Available),
`online_booking_status = 1`, and non-deleted vehicles are eligible. Statuses 0 and
2–7 remain internal to the existing fleet system and are never presented as client
or agent choices.

## New tables (30 additive `app_*` tables)

| New table                           | Important keys/fields                                                          | Purpose                                              |
| ----------------------------------- | ------------------------------------------------------------------------------ | ---------------------------------------------------- |
| `app_schema_migrations`             | Unique `filename`, SHA-256 `checksum`                                          | Prevent changed/replayed migrations                  |
| `app_service_catalog`               | Unique `code`, `legacy_service_id`, `booking_mode`                             | Unified five-service mobile catalog                  |
| `app_refresh_tokens`                | UUID PK, unique `token_hash`, `user_id`, expiry/revocation                     | Rotating login sessions                              |
| `app_user_devices`                  | Unique `device_id`, unique `push_token`, `user_id`                             | One-owner device and push registration               |
| `app_password_reset_tokens`         | Unique `token_hash`, expiry/used timestamps                                    | Password reset lifecycle                             |
| `app_user_oauth_accounts`           | Unique provider subject and unique `(user_id, provider)`                       | Verified Google identity linkage                     |
| `app_account_invitations`           | Unique `token_hash`, `role`, `user_id`, expiry, send count/time                | Approved Agent/Chauffeur onboarding and resend audit |
| `app_agent_customer_assignments`    | Unique `(agent_id, customer_id)`, `agency_id`, preferences                     | Personal client roster and authorization boundary    |
| `app_booking_drafts`                | Creator/client/agency, `service_code`, JSON `details`, `revision`              | Multi-step booking form state                        |
| `app_quote_snapshots`               | `draft_id`, revision/hash, decimal total, JSON breakdown, expiry               | Immutable checkout price                             |
| `app_reservation_meta`              | Unique `reservation_id`, `service_code`, source, lifecycle, ISO currency       | Mobile extension for a legacy reservation            |
| `app_reservation_leg_meta`          | Unique detail ID and `(reservation_id, sequence_no)`, class, precise locations | Detail-level passenger/location/status data          |
| `app_driver_assignments`            | Driver schedule index, reservation/detail IDs, state/timestamps                | Chauffeur assignment and acknowledgment              |
| `app_booking_status_events`         | Reservation/detail/assignment indexes, status/time/location                    | Append-only tracking timeline                        |
| `app_driver_locations`              | `(assignment_id, recorded_at)` and `(driver_id, recorded_at)` indexes          | Time-series GPS data                                 |
| `app_documents`                     | Owner/reservation indexes, storage key, visibility, MIME/size/expiry           | Protected documents and explicit media visibility    |
| `app_driver_expenses`               | Assignment/reservation/driver, decimal amount, review state                    | Expense submission and reimbursement review          |
| `app_incidents`                     | Reservation/assignment, severity, evidence IDs, resolution                     | Operational and safety incident workflow             |
| `app_booking_change_requests`       | Reservation/status index, prior lifecycle state, JSON changes, resolver        | Safe modifications without direct client mutation    |
| `app_booking_cancellation_requests` | Reservation/status index, prior lifecycle state, refund-pending state          | Approval and refund-aware cancellation               |
| `app_payment_transactions`          | Unique provider reference, decimal amount, ISO currency, refund ref            | Provider-facing payment lifecycle                    |
| `app_payment_webhook_events`        | Unique provider event                                                          | Webhook replay protection                            |
| `app_conversations`                 | Unique `reservation_id`                                                        | One conversation per booking                         |
| `app_conversation_participants`     | Unique `(conversation_id, user_id)`                                            | Authorized Client/Agent/Chauffeur/Support membership |
| `app_messages`                      | Conversation/time index, sender, text/document                                 | Paginated secure messaging                           |
| `app_masked_calls`                  | Reservation, initiator, recipient role, expiry                                 | Temporary call-bridge lifecycle                      |
| `app_notifications`                 | `(user_id, read_at, created_at)` index                                         | In-app/push notification inbox                       |
| `app_idempotency_keys`              | Unique `(user_id, scope, idempotency_key)`                                     | Duplicate checkout protection                        |
| `app_vip_requests`                  | Client/agency, airport/time/flight/status                                      | Manual Airport VIP workflow                          |
| `app_concierge_requests`            | Client/agency, category/text/time/status                                       | Manual concierge workflow                            |

## Financial storage

All new monetary values use `DECIMAL(12,2)` plus a three-letter ISO currency code. Legacy `double` and `€` fields are populated only where required for compatibility.

`tax_surecharges.amount` is confirmed and implemented as a percentage. For example, `5` means **5%**, calculated over the taxable base.

Agency commissions are not calculated or written by the mobile backend. Operations manages the legacy `agency_commissions` rows and the Agent app reads the recorded amount.

## Migration safety

- Migrations `001` and `002` are additive and do not rename/drop legacy objects.
- Migration `003` changes only app-owned tables: it renames existing app document storage values from `s3` to `spaces`, adds explicit private/public visibility, and records invitation delivery attempts. It does not alter a legacy website table.
- Migration `004` corrects only app-owned service mapping rows to `reservations.service_type`: Chauffeur 1, Rental 2, Transfer 3.
- Foreign keys are applied for new tables where legacy PK types are compatible.
- Applied migrations are checksum-protected.
- MySQL DDL performs implicit commits; take a backup and run first in staging even though the runner groups statements transactionally.
- The schema migration does not backfill old reservations into `app_reservation_meta`. A separate reviewed backfill is required if old bookings must appear in the new apps.
